# R5-D4 AUTOPILOT
## INSTRUCCIONES DE TRABAJO PARA CHATGPT
### DOCUMENTO DE REFERENCIA DEL PROYECTO

## 1. OBJETIVO GENERAL

El objetivo es construir un único script maestro en formato JSON, compatible con el reproductor Kinetic, que reúna todas las secuencias y configuraciones individuales proporcionadas por el usuario.

El script debe contener todas las combinaciones posibles de las opciones de configuración que se hayan preparado mediante las capturas JSON individuales.

No se trata de crear un configurador interactivo para seleccionar opciones manualmente.

Se trata de construir un único archivo JSON que, al ejecutarse en Kinetic, reproduzca automáticamente todas las secuencias previstas, en un orden establecido y conocido.

## 2. ARCHIVO BASE

Existe un archivo BASE independiente con esta configuración:

- Modo de limpieza: AUTO.
- Aspiración: OFF.
- Agua: OFF.
- TWICE: OFF.
- Hora: 00.
- Minutos: 00.
- Programación horaria: ACTIVADA.
- Lunes: ACTIVADO.
- Martes a domingo: DESACTIVADOS.

El lunes está activado obligatoriamente porque la aplicación necesita al menos un día seleccionado para mantener activa la programación horaria.

BASE es la referencia original y no debe modificarse.

## 3. CAPTURAS INDIVIDUALES

El usuario ha preparado archivos JSON individuales correspondientes a los distintos parámetros y opciones de configuración.

Las capturas de horas y minutos se realizan partiendo de BASE.

Para los días de la semana:

- El lunes ya está incluido en BASE.
- No necesita una captura adicional.
- Se realizan seis capturas nuevas: martes, miércoles, jueves, viernes, sábado y domingo.
- Cada captura parte nuevamente de BASE.
- El lunes permanece activado y se añade únicamente el día correspondiente.

Los JSON entregados constituyen la fuente de las secuencias que se utilizarán para construir el script maestro.

## 4. CONSTRUCCIÓN DEL SCRIPT MAESTRO

ChatGPT debe realizar el trabajo de integración de todas las secuencias.

El resultado debe ser un único archivo JSON compatible con Kinetic.

Debe respetarse el formato original de los archivos y conservarse correctamente la estructura de las secuencias.

Es imprescindible evitar que las distintas configuraciones se sobrescriban accidentalmente.

El objetivo es incluir todas las combinaciones posibles de los parámetros proporcionados, teniendo en cuenta que las órdenes pueden contener bloques completos de configuración.

No inventar secuencias ni valores que no estén respaldados por los archivos recibidos.

No sustituir el programador interno del robot por un controlador externo.

## 5. ORDEN DE EJECUCIÓN E ÍNDICE DE REFERENCIAS

ESTE APARTADO ES FUNDAMENTAL.

ChatGPT será responsable de establecer el orden completo de ejecución del script maestro.

Antes de entregar el JSON definitivo deberá preparar un índice de referencias independiente que documente:

- Número de secuencia.
- Nombre de la función o configuración.
- JSON de origen.
- Orden exacto de ejecución.
- Posición de inicio y final de cada secuencia dentro de la ejecución.
- Identificación de los bloques y órdenes que componen cada secuencia.

El índice debe corresponder exactamente al JSON maestro entregado.

El usuario no tendrá que crear este índice ni identificar manualmente las funciones.

El propósito es conocer de antemano qué secuencia se está ejecutando en cada momento y poder relacionarla posteriormente con las comunicaciones capturadas.

El reproductor Kinetic ejecutará el JSON maestro. No se presupone que tenga que generar archivos TXT, CSV ni registros auxiliares.

## 6. CAPTURA PCAPDROID

Una vez preparado el JSON maestro y su índice, el usuario lo importará en Kinetic.

Durante toda la ejecución, PCAPdroid permanecerá funcionando en segundo plano y capturará las comunicaciones de red.

El filtro de captura está configurado para observar principalmente las comunicaciones entre:

- R5-D4, el robot.
- El hotspot Android, que proporciona conexión a Internet.

También pueden aparecer comunicaciones del robot con servidores externos a través de ese hotspot.

Por tanto, no debe suponerse que todo el tráfico capturado corresponde exclusivamente a las órdenes de Kinetic.

## 7. ANÁLISIS POSTERIOR DEL PCAP

Una vez terminada la ejecución, el usuario entregará a ChatGPT:

- El archivo PCAPdroid.
- El JSON maestro ejecutado.
- El índice de referencias generado durante la construcción del script.
- Los archivos JSON originales, si fueran necesarios para verificar alguna secuencia.

ChatGPT será responsable de relacionar las comunicaciones capturadas con las secuencias del script maestro.

Para ello utilizará:

- El orden de ejecución previamente establecido.
- Las referencias de inicio y final.
- Los tiempos de las secuencias.
- Los tiempos de envío y recepción de paquetes.
- Las direcciones IP y puertos.
- La continuidad de las comunicaciones TCP.
- Los tamaños y patrones de las tramas.

Aunque el contenido de las comunicaciones pueda estar cifrado, se utilizarán las referencias temporales y estructurales para identificar las correspondencias.

IMPORTANTE: El usuario no debe tener que identificar manualmente qué trama corresponde a cada función. Esa responsabilidad corresponde a ChatGPT.

No pedir al usuario que vuelva a realizar manualmente una identificación que pueda obtenerse mediante el índice y el análisis del PCAP.

## 8. REGLAS DE TRABAJO

- Mantener la continuidad del proyecto.
- Leer este documento antes de empezar.
- No pedir información que ya esté especificada aquí.
- No cambiar el objetivo del proyecto.
- No convertir el trabajo en una investigación de ingeniería inversa ajena a la tarea solicitada.
- No limitarse a explicar cómo integrar los archivos: realizar la integración.
- No generar órdenes de movimiento durante esta fase.
- No dar por terminada una integración sin comprobar que el JSON maestro conserva las secuencias originales necesarias.

## 9. RESULTADO FINAL ESPERADO

Entregar:

1. Un único JSON maestro para importar y ejecutar en Kinetic.
2. Un índice de referencias que documente exactamente su orden de ejecución.
3. La correspondencia entre las secuencias ejecutadas y las comunicaciones del PCAP, una vez recibida la captura.

El objetivo final es disponer de una base completa y organizada para continuar desarrollando R5-D4 AUTOPILOT y aprovechar su programador interno para el funcionamiento autónomo del robot.
